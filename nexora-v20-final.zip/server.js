
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

const db = new sqlite3.Database("./db.sqlite");

db.serialize(()=>{
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT)");
  db.run("CREATE TABLE IF NOT EXISTS channels (id INTEGER PRIMARY KEY, name TEXT)");
  db.run("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, content TEXT, channel TEXT)");
});

app.use(express.json());
app.use(express.static("public"));

app.post("/api/register",(req,res)=>{
  const {username,password} = req.body;
  db.run("INSERT INTO users(username,password,role) VALUES(?,?,?)",[username,password,"user"]);
  res.json({ok:true});
});

app.post("/api/login",(req,res)=>{
  const {username,password} = req.body;
  db.get("SELECT * FROM users WHERE username=? AND password=?",[username,password],(err,row)=>{
    res.json({ok:!!row,user:row});
  });
});

app.post("/api/channel",(req,res)=>{
  db.run("INSERT INTO channels(name) VALUES(?)",[req.body.name]);
  res.json({ok:true});
});

app.get("/api/channels",(req,res)=>{
  db.all("SELECT * FROM channels",(e,rows)=>res.json(rows));
});

app.get("/admin",(req,res)=>{
  res.sendFile(path.join(__dirname,"public/admin.html"));
});

function ai(msg){
  if(msg.includes("merhaba")) return "Selam 👋";
  return "AI aktif 🤖";
}

io.on("connection",(socket)=>{
  socket.on("join",(c)=>socket.join(c));
  socket.on("chat",(d)=>{
    db.run("INSERT INTO messages(content,channel) VALUES(?,?)",[d.msg,d.channel]);
    io.to(d.channel).emit("chat",d.msg);
  });
  socket.on("ai",(m)=>socket.emit("ai",ai(m)));
});

server.listen(PORT,()=>console.log("Running "+PORT));
