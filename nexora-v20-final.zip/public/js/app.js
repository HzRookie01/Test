
const s=io();
const msgBox=document.getElementById("messages");

function loadChannels(){
 fetch('/api/channels').then(r=>r.json()).then(d=>{
  let sel=document.getElementById("channel");
  sel.innerHTML="";
  d.forEach(c=>sel.innerHTML+=`<option>${c.name}</option>`);
 });
}

function send(){
 let m=document.getElementById("msg").value;
 let c=document.getElementById("channel").value;
 s.emit("chat",{msg:m,channel:c});
}

function askAI(){
 let m=document.getElementById("msg").value;
 s.emit("ai",m);
}

s.on("chat",m=>msgBox.innerHTML+=`<div class='msg'>${m}</div>`);
s.on("ai",m=>msgBox.innerHTML+=`<div class='ai'>${m}</div>`);
